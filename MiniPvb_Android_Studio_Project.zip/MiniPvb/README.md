# Mini Pvb — Android başlangıç projesi

Bu, Android Studio ile açılabilen bir başlangıç projesidir (Android 16 / API 36 hedefi).

## Şu anda neler var?
- Mini Pvb adı ve VPN ana ekranı
- Hollanda sunucusu seçimi için arayüz
- Bağlan düğmesi ve eksik sunucu yapılandırması uyarısı
- Android 16 hedef SDK ayarı

## Önemli
Bu proje şu an **gerçek VPN bağlantısı kurmaz** ve hazır APK değildir.
WireGuard ile gerçek bağlantı için kullanıcının yetkili bir VPN sağlayıcısından aldığı
WireGuard yapılandırması ve güvenli tünel entegrasyonu gerekir. Rastgele sunucu adresleri
veya başkasına ait anahtarlar kullanılmamalıdır.

## APK oluşturma
1. Android Studio'da bu klasörü aç.
2. Gradle eşitlemesinin tamamlanmasını bekle.
3. Build > Build Bundle(s) / APK(s) > Build APK(s) seç.
4. Test için yalnızca güvendiğin, yetkili VPN sağlayıcısının yapılandırmasını kullan.
