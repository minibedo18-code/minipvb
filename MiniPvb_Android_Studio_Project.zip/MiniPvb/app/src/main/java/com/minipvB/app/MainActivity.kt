package com.minipvB.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val bg = Color.rgb(12, 22, 38)
        val white = Color.WHITE
        val muted = Color.rgb(185, 199, 216)
        val green = Color.rgb(27, 166, 111)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 40, 32, 40)
            setBackgroundColor(bg)
        }

        fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView {
            return TextView(this).apply {
                text = value
                textSize = size
                setTextColor(color)
                gravity = Gravity.CENTER
                if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
                setPadding(8, 12, 8, 12)
            }
        }

        layout.addView(text("Mini Pvb", 34f, white, true))
        layout.addView(text("ÜCRETSİZ VPN • ANDROID 16", 12f, muted))
        layout.addView(text("🇳🇱", 64f, white))
        layout.addView(text("Hollanda sunucusu", 22f, white, true))
        layout.addView(text("Durum: Sunucu ayarı bekleniyor", 15f, muted))

        val connect = Button(this).apply {
            this.text = "BAĞLAN"
            setTextColor(white)
            setBackgroundColor(green)
            textSize = 18f
            setOnClickListener {
                Toast.makeText(
                    this@MainActivity,
                    "Gerçek bağlantı için yetkili bir Hollanda WireGuard sunucu yapılandırması gerekiyor.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
        layout.addView(connect, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 58
        ).apply { topMargin = 28 })

        layout.addView(text(
            "Bilgi: Bu başlangıç sürümünde arayüz hazırdır. Henüz VPN tüneli kurulmaz. " +
            "Ücretsiz sunucu sağlayıcısından alınan WireGuard yapılandırması eklenmelidir.",
            13f, muted
        ))

        setContentView(layout)
    }
}
